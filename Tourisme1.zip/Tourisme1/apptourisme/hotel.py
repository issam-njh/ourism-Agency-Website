import os
import sqlite3
from django.db import models
from models import Hotel
DB_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import tourisme.manage

if __name__ == '__manage__':
    main()


DB_PATH = os.path.join(DB_DIR, "db.sqlite3")

hotel = Hotel(nomHotel="Marina Mar",descriptionHotel="Hotel au bord de la marina",noteHotel="4")
Hotel.objects.get(id=1)
