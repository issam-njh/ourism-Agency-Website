from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import hotel
from apptourisme.views import (index,)
from .views import transport,activite,restaurant
from .views import Contact_Create_View
from .views import Visite_Create_View


urlpatterns = [

    path('hotel/', hotel, name='hotel'),
    path('restaurant/', restaurant, name='restaurant'),
    path('activite/', activite, name='activite'),
    path('transport/', transport, name='transport'),
    path('contact/', Contact_Create_View, name='contact'),
    path('visite/', Visite_Create_View, name='Visite'),
    path('', index),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
