from django.apps import AppConfig


class ApptourismeConfig(AppConfig):
    name = 'apptourisme'
